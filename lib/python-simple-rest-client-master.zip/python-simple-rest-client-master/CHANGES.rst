Changelog
---------

0.3.0
~~~~~

* Add client_response in Response object.

0.2.0
~~~~~

* Add asyncio support (aiohttp).

0.1.1
~~~~~

* Add MANIFEST.in (fix install by pip).

0.1.0
~~~~~

* Initial release.
